import serial
import copy
import threading

from serial.threaded import LineReader, ReaderThread

class CustomInputDevice:

    def __init__(self, port, baudrate = 9600):
        self.serial_port = serial.Serial(port, baudrate = baudrate)
        self.running = False
        self.reading = 0

    def start(self):
        device = self
        class PrintLines(LineReader):
            def connection_made(self, transport):
                print("Connection Made")
                self.transport = transport

            def connection_lost(self):
                print("Connection Closed")

            def handle_line(self, data):
                try:
                    device.reading = int(data)
                except ValueError:
                    pass

        def reader_loop():
            with ReaderThread(self.serial_port, PrintLines) as protocol:
                self.running = True
                while self.running:
                    pass            
        
        self.reader_loop_thread = threading.Thread(target=reader_loop)

        self.reader_loop_thread.start()

    def stop(self):
        self.running = False
        self.reader_loop_thread.join()
        self.serial_port.close()
        

    def get_reading(self):
        ret_value = copy.copy(self.reading)
        return ret_value