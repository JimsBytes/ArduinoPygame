# Batty the Bat
#
# Authors: Steven Mead & James Fairbairn
#
# Simple game to test the Arduino/UltraSonic sensors input device

import os
from math import sqrt
from random import randint
import pygame
import spritehelper
from custom_input_device import CustomInputDevice

from itertools import cycle

pygame.init()
pygame.display.set_caption("Batty the bat")

# Speed we want to run the game at
FPS = 60
CLOCK = pygame.time.Clock()

# Windowing
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

canvas = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Game constants
TRANSFORM_SIZE = 4
BACKGROUND_WIDTH = 928
BACKGROUND_HEIGHT = 793
MOON_WIDTH = 128
MOON_HEIGHT = 128
MOON_RADIUS = int(MOON_WIDTH / 2)
BATTY_WIDTH = 32
BATTY_HEIGHT = 32
BATTY_RADIUS = int(BATTY_WIDTH / 2) * TRANSFORM_SIZE

# Assets
MOON = pygame.image.load(os.path.join("assets", "moon.png")).convert()
BACKGROUND = pygame.image.load(os.path.join("assets", "background.png")).convert()
BATTY = pygame.image.load(os.path.join("assets", "32x32-bat-sprite.png")).convert()

# Background layer
background_layer = pygame.Surface((BACKGROUND_WIDTH*2, SCREEN_HEIGHT))
background_layer.blit(BACKGROUND, (0,SCREEN_HEIGHT-BACKGROUND_HEIGHT))
background_layer.blit(BACKGROUND, (BACKGROUND_WIDTH,SCREEN_HEIGHT-BACKGROUND_HEIGHT))

# Create moon image
moon_sprite = spritehelper.slice(MOON, 1, 1, MOON_WIDTH, MOON_HEIGHT, 1, 0)[0]

# Create Batty's sprites
batty_sprites = spritehelper.slice(BATTY, 4, 4, BATTY_WIDTH, BATTY_HEIGHT, TRANSFORM_SIZE, 0)

# Player centre screen
batty_x_position = int(SCREEN_WIDTH / 2) - int((BATTY_WIDTH*TRANSFORM_SIZE) / 2)
batty_y_position = int(SCREEN_HEIGHT / 2) - int((BATTY_HEIGHT*TRANSFORM_SIZE) / 2)
delta_x = 0
delta_y = 0

# Moon initial position
moon_x_position = int(SCREEN_WIDTH / 2)
moon_y_position = 10

# Background x position
background_x = 0

# Simple animation for the character
#
BATTY_ANIMATIONS = {  "idle": (0, 1, 2, 3),
                "right": (4, 5, 6, 7),
                "left": (12, 13, 14, 15) }
animation_state = "idle"
animate = cycle(BATTY_ANIMATIONS[animation_state])
sprite_index = 0
sprite_tick = 0
sprite_tick_delay = 12

# For simplicity, hardcode the delta time.
#
dt = 0.4


try:
    # Enter the game loop.
    #
    run = True

    while run:
        CLOCK.tick(FPS)
                  
        batty_x_position += delta_x * 10 * dt # multiply by dt smooths the movement based on time

        if delta_x < 0 and animation_state != "left":
            animation_state = "left"
            animate = cycle(BATTY_ANIMATIONS[animation_state])
        elif delta_x > 0 and animation_state != "right":
            animation_state = "right"
            animate = cycle(BATTY_ANIMATIONS[animation_state])
        elif animation_state != "idle":
            animation_state = "idle"
            animate = cycle(BATTY_ANIMATIONS[animation_state])

        batty_y_position -= delta_y * 10 * dt



        # Check the events that occurred during this frame
        #
        for event in pygame.event.get():
            # For simplicity, we'll only check that the user
            # has decided to close the window.
            #
            if event.type == pygame.QUIT:
                run = False
                
        # Colour values are (R, G, B)
        canvas.fill((255, 255, 255)) # Fill the canvas with white 

        # Does the animation frame need updating.
        #
        if sprite_tick >= sprite_tick_delay:
            sprite_index = next(animate)
            sprite_tick = 0
                
        # Background at a fixed position
        #
        canvas.blit(background_layer, (0, 0))

        # Moon at its current position
        #
        canvas.blit(moon_sprite, (moon_x_position, moon_y_position))

        # Sprites
        canvas.blit(batty_sprites[sprite_index], (batty_x_position,batty_y_position))

        # Update window and counters
        window.blit(canvas, (0,0))
        pygame.display.update()
        sprite_tick += 1

except KeyboardInterrupt:
    # If the user presses CTRL+C to force the program
    # to quit, we must stop the input device properly
    # otherwise the application won't shutdown correctly.
    pass
    
# Be nice, shut down things properly.
pygame.quit()