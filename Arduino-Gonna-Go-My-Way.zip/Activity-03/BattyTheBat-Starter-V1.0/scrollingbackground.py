
import pygame


class ScrollingBackground:

    def __init__(self):
        self.surface = None
        self.tick = 0
        

    def scroll(self):
        pass