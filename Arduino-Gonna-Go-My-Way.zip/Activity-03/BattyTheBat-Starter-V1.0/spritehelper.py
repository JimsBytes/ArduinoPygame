# Functions for splitting sprite sheets
# James Fairbairn 05/09/2021

import pygame

from typing import List
from typing import Tuple

def slice(
    source: pygame.Surface, 
    rows: int, 
    columns: int, 
    width: int, 
    height: int, 
    transform_scale: int = 1,
    trim: int = 0) -> List[pygame.Surface]:

    sprites = []
    y = 0
    for _ in range(rows):
        x = 0
        for _ in range(columns):
            sprite = pygame.Surface((width, height))
            sprite.set_colorkey((0,0,0))
            w = x + width
            h = y + height
            sprite.blit(source, (0,0), (x,y,w,h))
            sprite = pygame.transform.scale(sprite, (width*transform_scale,height*transform_scale))
            sprites.append(sprite)
            x += width
        y += height

    if trim > 0:
        del(sprites[-3:])

    print("Loaded -", len(sprites), " sprites from the sprite sheet")
    
    return tuple(sprites)

