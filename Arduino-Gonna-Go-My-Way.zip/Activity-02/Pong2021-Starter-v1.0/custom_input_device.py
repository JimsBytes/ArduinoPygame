import serial
import copy
import time
import threading

from serial.threaded import LineReader, ReaderThread

class CustomInputDevice:

    def __init__(self, port, baudrate = 9600):
        self.serial_port = serial.Serial(port, baudrate = baudrate)
        self.running = False
        self.reading = (0,0)

    def start(self):
        device = self
        class PrintLines(LineReader):
            def connection_made(self, transport):
                print("Connection Made")
                self.transport = transport

            def connection_lost(self, exc):
                print("Connection Closed")

            def handle_line(self, data):
                try:
                    device.reading = tuple(map(lambda val: int(val), data.split(",")))
                except ValueError:
                    pass

        def reader_loop():
            with ReaderThread(self.serial_port, PrintLines) as protocol:
                self.running = True
                while self.running:
                    time.sleep(0.01)            
        
        self.reader_loop_thread = threading.Thread(target=reader_loop)
        self.reader_loop_thread.start()

    def stop(self):
        self.running = False
        self.reader_loop_thread.join()
        self.serial_port.close()
        

    def get_reading(self):
        ret_value = copy.copy(self.reading)
        return ret_value

# if __name__ == "__main__":
#     try:
#         custom_input_device_test = CustomInputDevice(port = "/dev/ttyACM1")
#         custom_input_device_test.start()
#         while True:
#             print(custom_input_device_test.get_reading())
#             # x, y = custom_input_device_test.read()
#             # print("Distance: ", x, y)
#     except KeyboardInterrupt:
#         custom_input_device_test.stop()
#     except Exception as e:
#         print("Unknown error", e)
#     print("Finished")